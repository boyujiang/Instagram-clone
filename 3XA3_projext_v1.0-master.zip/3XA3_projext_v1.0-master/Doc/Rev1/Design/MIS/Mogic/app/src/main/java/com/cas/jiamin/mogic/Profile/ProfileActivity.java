package com.cas.jiamin.mogic.Profile;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;


import com.cas.jiamin.mogic.AccountsettingActivity.AccountsettingActivity;
import com.cas.jiamin.mogic.AccountsettingActivity.LoginActivity;
import com.cas.jiamin.mogic.AccountsettingActivity.RegisterActivity;
import com.cas.jiamin.mogic.Home.HomeActivity;
import com.cas.jiamin.mogic.R;
import com.cas.jiamin.mogic.Search.SearchActivity;
import com.cas.jiamin.mogic.Share.ShareActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;

public class ProfileActivity extends AppCompatActivity {
    private static final String TAG = "ProfileActivity";
    private ProgressBar localprogressBar;
    private DatabaseReference mReference;
    private FirebaseAuth mAuth;
    private static final int PICK_IMAGE_REQUEST = 234;
    private ImageView imageView;
    private FirebaseUser user;
    private Uri filePath;
    private TextView UN;
    private TextView DE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        Log.d(TAG, "onCreate: started.");
        mAuth = FirebaseAuth.getInstance();
        mReference = FirebaseDatabase.getInstance().getReference();
        user = mAuth.getCurrentUser();
        imageView = (ImageView) findViewById(R.id.profile_image);
        UN = (TextView) findViewById(R.id.display_name);
        DE = (TextView) findViewById(R.id.display_descrip);
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomBar);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.ic_home:{
                        Intent intent1 = new Intent(ProfileActivity.this, HomeActivity.class);
                        startActivity(intent1);
                        break;
                    }
                    case R.id.ic_search:{
                        Intent intent2 = new Intent(ProfileActivity.this, SearchActivity.class);
                        startActivity(intent2);
                        break;
                    }
                    case R.id.ic_share:{
                        Intent intent3 = new Intent(ProfileActivity.this, ShareActivity.class);
                        startActivity(intent3);
                        break;
                    }
                    /*
                    case R.id.ic_profile:{
                        Intent intent4 = new Intent(ProfileActivity.this, ProfileActivity.class);
                        startActivity(intent4);
                    }
                    */
                }
                return false;
            }
        });

        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(3);
        menuItem.setChecked(true);
        setupToolbar();

        localprogressBar = (ProgressBar) findViewById(R.id.profprogbar);
        localprogressBar.setVisibility(View.GONE);

        if (user != null) {
            /*filePath = user.getPhotoUrl();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),filePath);
                imageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }*/

            String UName = user.getDisplayName();
            UN.setText(UName);

            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference URef = database.getReference("Users");
            DatabaseReference myRef = URef.child(user.getUid());
            DatabaseReference des = myRef.child("UserDesc");
            des.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    //数据库数据变化时调用此方法
                    String value = dataSnapshot.getValue(String.class);
                    DE.setText(value);
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }

    }

    private void setupToolbar(){
        Toolbar toolbar = (Toolbar) findViewById(R.id.profToolBar);
        setSupportActionBar(toolbar);
        ImageView profileMenu = (ImageView)findViewById(R.id.profilemenu);
        profileMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "OnClick: nav to account setting");
                Intent intent = new Intent(ProfileActivity.this, AccountsettingActivity.class);
                startActivity(intent);
            }
        });
    }

    public void buttonedit(View view)
    {
        Intent intent=new Intent(ProfileActivity.this, EditprofileActivity.class);
        startActivity(intent);
    }
}
