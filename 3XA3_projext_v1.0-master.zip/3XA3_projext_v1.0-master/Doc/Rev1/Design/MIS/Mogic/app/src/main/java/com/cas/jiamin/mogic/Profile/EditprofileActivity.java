package com.cas.jiamin.mogic.Profile;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.cas.jiamin.mogic.AccountsettingActivity.AccountsettingActivity;
import com.cas.jiamin.mogic.Home.HomeActivity;
import com.cas.jiamin.mogic.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;

public class EditprofileActivity extends AppCompatActivity {
    private static final String TAG = "EditprofileActivity";
    private DatabaseReference mReference;
    private FirebaseAuth mAuth;
    private static final int PICK_IMAGE_REQUEST = 234;
    private ImageView imageView;
    private FirebaseUser user;
    private Uri filePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editprofile);
        ImageView edprotab = (ImageView) findViewById(R.id.backArrow);
        edprotab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "OnClick: nav to profile");
                Intent intent = new Intent(EditprofileActivity.this, AccountsettingActivity.class);
                startActivity(intent);
            }
        });
        mAuth = FirebaseAuth.getInstance();
        mReference = FirebaseDatabase.getInstance().getReference();
        user = mAuth.getCurrentUser();
        imageView = (ImageView) findViewById(R.id.profile_photo);
        //filePath = user.getPhotoUrl();
    }

    public void change (View view){
        showFileChooser();
    }

    public void save (View view){
        EditText un = (EditText) findViewById(R.id.eusername);
        String UName = un.getText().toString();
        EditText desc = (EditText) findViewById(R.id.edescription);
        String description = desc.getText().toString();
        EditText email = (EditText) findViewById(R.id.eemail);
        String Email = email.getText().toString();
        EditText pw = (EditText) findViewById(R.id.epassword);
        String password = pw.getText().toString();

        if (filePath != null){
            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                    .setPhotoUri(filePath)
                    .build();

            user.updateProfile(profileUpdates)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(EditprofileActivity.this, "User icon updated", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(EditprofileActivity.this, "failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }

        if (UName.length() != 0) {
            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                    .setDisplayName(UName)
                    .build();

            user.updateProfile(profileUpdates)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(EditprofileActivity.this, "User name updated", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(EditprofileActivity.this, "failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }

        if (description.length() != 0){
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference URef = database.getReference("Users");
            DatabaseReference myRef = URef.child(user.getUid());
            myRef.child("UserDesc").setValue(description);
            Toast.makeText(EditprofileActivity.this, "User description updated", Toast.LENGTH_SHORT).show();
        }

        if (Email.length() != 0){
            user.updateEmail(Email)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(EditprofileActivity.this, "Email update success", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
        }

        if (password.length() != 0){
            user.updatePassword(password)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(EditprofileActivity.this, "password update success", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
        }


        Intent i = new Intent(EditprofileActivity.this, HomeActivity.class);
        startActivity(i);
    }

    private void showFileChooser(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select an Image"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data !=null && data.getData() !=null){
            filePath = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),filePath);
                imageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
