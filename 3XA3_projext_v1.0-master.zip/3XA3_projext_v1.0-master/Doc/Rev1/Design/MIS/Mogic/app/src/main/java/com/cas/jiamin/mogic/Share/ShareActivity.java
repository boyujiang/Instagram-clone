package com.cas.jiamin.mogic.Share;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.cas.jiamin.mogic.Home.HomeActivity;
import com.cas.jiamin.mogic.Profile.ProfileActivity;
import com.cas.jiamin.mogic.R;
import com.cas.jiamin.mogic.Search.SearchActivity;

public class ShareActivity extends AppCompatActivity {
    private static final String TAG = "ShareActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Log.d(TAG, "onCreate: started.");

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomBar);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.ic_home: {
                        Intent intent1 = new Intent(ShareActivity.this, HomeActivity.class);
                        startActivity(intent1);
                        break;
                    }
                    case R.id.ic_search: {
                        Intent intent2 = new Intent(ShareActivity.this, SearchActivity.class);
                        startActivity(intent2);
                        break;
                    }
                    /*
                    case R.id.ic_share:{
                        Intent intent3 = new Intent(ShareActivity.this, ShareActivity.class);
                        startActivity(intent3);
                    }
                    */
                    case R.id.ic_profile: {
                        Intent intent4 = new Intent(ShareActivity.this, ProfileActivity.class);
                        startActivity(intent4);
                        break;
                    }
                }
                return false;
            }
        });

        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);
    }
}