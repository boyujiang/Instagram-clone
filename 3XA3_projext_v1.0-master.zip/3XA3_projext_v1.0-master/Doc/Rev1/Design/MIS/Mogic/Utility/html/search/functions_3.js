var searchData=
[
  ['recyclerviewadapter',['RecyclerViewAdapter',['../classcom_1_1cas_1_1jiamin_1_1mogic_1_1_utility_1_1_recycler_view_adapter.html#a54846a45fcb413a360a1e793fcbb37dc',1,'com::cas::jiamin::mogic::Utility::RecyclerViewAdapter']]]
];
