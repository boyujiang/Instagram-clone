var searchData=
[
  ['viewholder',['ViewHolder',['../classcom_1_1cas_1_1jiamin_1_1mogic_1_1_utility_1_1_recycler_view_adapter_1_1_view_holder.html',1,'com::cas::jiamin::mogic::Utility::RecyclerViewAdapter']]]
];
