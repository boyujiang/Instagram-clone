var searchData=
[
  ['save',['save',['../classcom_1_1cas_1_1jiamin_1_1mogic_1_1_profile_1_1_editprofile_activity.html#a25a9db936740bc716d74e7feb0b19f79',1,'com::cas::jiamin::mogic::Profile::EditprofileActivity']]]
];
