var searchData=
[
  ['onactivityresult',['onActivityResult',['../classcom_1_1cas_1_1jiamin_1_1mogic_1_1_profile_1_1_editprofile_activity.html#a4996cc7d4c542fb9ac52e4ddfa47bbd1',1,'com::cas::jiamin::mogic::Profile::EditprofileActivity']]],
  ['oncreate',['onCreate',['../classcom_1_1cas_1_1jiamin_1_1mogic_1_1_profile_1_1_editprofile_activity.html#ad41b4c210820b92f85bd8690e6d5e82a',1,'com.cas.jiamin.mogic.Profile.EditprofileActivity.onCreate()'],['../classcom_1_1cas_1_1jiamin_1_1mogic_1_1_profile_1_1_profile_activity.html#aabcc4bd3e7d28db7dbd7029c0a12dca0',1,'com.cas.jiamin.mogic.Profile.ProfileActivity.onCreate()']]]
];
