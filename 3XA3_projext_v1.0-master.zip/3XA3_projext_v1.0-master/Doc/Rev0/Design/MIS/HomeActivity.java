package com.cas.jiamin.mogic.Home;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.cas.jiamin.mogic.Profile.ProfileActivity;
import com.cas.jiamin.mogic.R;
import com.cas.jiamin.mogic.Search.SearchActivity;
import com.cas.jiamin.mogic.Share.ShareActivity;
import com.google.firebase.auth.FirebaseAuth;

/** Brief the home activity that demonstrate the main page of the project
 *  
 */
public class HomeActivity extends AppCompatActivity {
    private static final String TAG = "HomeActivity"; /**< TAG "HomeActivity" for easier reference */
    private FirebaseAuth mAuth; /**< FireBase Variable to use its functions */

	
    @Override
	/** Brief onCreate function which is the default runing function to keep the property of the activity
	 *  @param Bundle savedInstanceState
	 */
    protected void onCreate(Bundle savedInstanceState) {
		/** create instance based on current state
		 *  
		 */
        super.onCreate(savedInstanceState);
		/** link current instance to layout activity_home
		 *  
		 */
        setContentView(R.layout.activity_home); 
        Log.d(TAG, "onCreate: started.");

		/** create navigation tool bar instance
		 *  
		 */
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomBar);
		/** set navigation tool bar instance clickable
		 *  
		 */
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
			/** create item select function to react with click on icon
			 *  @param MenuItem item navigation bar item
			 */
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) { 
                    /*
                    case R.id.ic_home:{
                        Intent intent1 = new Intent(HomeActivity.this, HomeActivity.class);
                        startActivity(intent1);
                    }
                    */
					
					/** First case link from HomeActivity to SearchActivity
					 *  
					 */
                    case R.id.ic_search: {
                        Intent intent2 = new Intent(HomeActivity.this, SearchActivity.class);
                        startActivity(intent2);
                        break;
                    }
					
					/** First case link from HomeActivity to ShareActivity
					 *  
					 */
                    case R.id.ic_share: {
                        Intent intent3 = new Intent(HomeActivity.this, ShareActivity.class);
                        startActivity(intent3);
                        break;
                    }
					
					/** First case link from HomeActivity to ProfileActivity
					 *  
					 */
                    case R.id.ic_profile: {
                        Intent intent4 = new Intent(HomeActivity.this, ProfileActivity.class);
                        startActivity(intent4);
                        break;
                    }
                }
                return false;
            }
        });

		/** set labeled icon for local activity
		 *  
		 */
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);
    }
}


