package com.cas.jiamin.mogic.Profile;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.cas.jiamin.mogic.AccountsettingActivity.AccountsettingActivity;
import com.cas.jiamin.mogic.Home.HomeActivity;
import com.cas.jiamin.mogic.R;
import com.cas.jiamin.mogic.Search.SearchActivity;
import com.cas.jiamin.mogic.Share.ShareActivity;

/** Brief the profile activity that demonstrate the profile page of the project
 *  
 */
public class ProfileActivity extends AppCompatActivity {
    private static final String TAG = "ProfileActivity"; /**< TAG "ProfileActivity" for easier reference */
    private ProgressBar localprogressBar; /**< progressbar Variable created to reference */

	
    @Override
	/** Brief onCreate function which is the default runing function to keep the property of the activity
	 *  @param Bundle savedInstanceState
	 */
    protected void onCreate(Bundle savedInstanceState) {
		/** create instance based on current state
		 *  
		 */
        super.onCreate(savedInstanceState);
		/** link current instance to layout activity_profile
		 *  
		 */
        setContentView(R.layout.activity_profile);
        Log.d(TAG, "onCreate: started.");
		
		/** create navigation tool bar instance
		 *  
		 */
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomBar);
		/** set navigation tool bar instance clickable
		 *  
		 */
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            
			@Override
			/** create item select function to react with click on icon
			 *  @param MenuItem item navigation bar item
			 */
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    /** First case link from ProfileActivity to HomeActivity
					 *  
					 */
					case R.id.ic_home: {
                        Intent intent1 = new Intent(ProfileActivity.this, HomeActivity.class);
                        startActivity(intent1);
                        break;
                    }
					
					/** Second case link from ProfileActivity to SearchActivity
					 *  
					 */
                    case R.id.ic_search: {
                        Intent intent2 = new Intent(ProfileActivity.this, SearchActivity.class);
                        startActivity(intent2);
                        break;
                    }
					
					/** Third case link from ProfileActivity to ShareActivity
					 *  
					 */
                    case R.id.ic_share: {
                        Intent intent3 = new Intent(ProfileActivity.this, ShareActivity.class);
                        startActivity(intent3);
                        break;
                    }
                    /*
                    case R.id.ic_profile:{
                        Intent intent4 = new Intent(ProfileActivity.this, ProfileActivity.class);
                        startActivity(intent4);
                    }
                    */
                }
                return false;
            }
        });

		/** set labeled icon for local activity
		 *  
		 */
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(3);
        menuItem.setChecked(true);
		
		/** execute labeled icon for local activity
		 *  
		 */
        setupToolbar();

		/** initialize progressbar variable to id profprogbar
		 *  
		 */
        localprogressBar = (ProgressBar) findViewById(R.id.profprogbar);
        localprogressBar.setVisibility(View.GONE);
    }

	/** Brief setupToolbar function create to set tool bar dor profile page
	 *  
	 */
    private void setupToolbar() {
		/** create toolbar variable and assign to toolbar with id profToolBar
		 *  
		 */
        Toolbar toolbar = (Toolbar) findViewById(R.id.profToolBar);
        setSupportActionBar(toolbar);
		
		/**Brief image view object to click on image has id profilemenu
		 *  
		 */
        ImageView profileMenu = (ImageView) findViewById(R.id.profilemenu);
		
		/** Brief create item select function to react with click on icon
		 *  @param MenuItem item navigation bar item
		 */
        profileMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "OnClick: nav to account setting");
                Intent intent = new Intent(ProfileActivity.this, AccountsettingActivity.class);
                startActivity(intent);
            }
        });
    }
}
