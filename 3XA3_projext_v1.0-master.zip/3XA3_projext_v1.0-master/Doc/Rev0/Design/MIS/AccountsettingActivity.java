package com.cas.jiamin.mogic.AccountsettingActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.cas.jiamin.mogic.Profile.ProfileActivity;
import com.cas.jiamin.mogic.R;

/** Brief the AccountSetting activity that demonstrate the main page of the project
 *  
 */
public class AccountsettingActivity extends AppCompatActivity {
    private static final String TAG = "AccountsettingActivity"; /**< TAG "AccountSettingActivity" for easier reference */

    @Override
	/** Brief onCreate function which is the default runing function to keep the property of the activity
	 *  @param Bundle savedInstanceState
	 */
    protected void onCreate(@NonNull Bundle savedInstanceState) {
		/** create instance based on current state
		 *  
		 */
        super.onCreate(savedInstanceState);
		/** link current instance to layout activity_home
		 *  
		 */
        setContentView(R.layout.activity_account_settings);
        Log.d(TAG, "onCreate Started");
        setupAcset();
    }

	/** Brief set clickable instance
	 *  
	 */
    private void setupAcset() {
        Log.d(TAG, "setupSetting: initializing AccountSetting");
		/** Brief create item select function to react with click on image
		 * 
		 */
        ImageView acsettab = (ImageView) findViewById(R.id.acsetbk);
        acsettab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "OnClick: nav to profile");
                Intent intent = new Intent(AccountsettingActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });

		/** Brief create item select function to react with click on button
		 *  
		 */
        Button reg = (Button) findViewById(R.id.acsetsignout);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "OnClick: nav to register");
                Intent intent = new Intent(AccountsettingActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}
