# Module Interface Specification #

Use doxygen (or equivalent) to document the interface for your modules.
