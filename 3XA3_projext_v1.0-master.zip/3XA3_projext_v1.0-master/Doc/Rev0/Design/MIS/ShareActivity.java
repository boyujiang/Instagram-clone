package com.cas.jiamin.mogic.Share;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.cas.jiamin.mogic.Home.HomeActivity;
import com.cas.jiamin.mogic.Profile.ProfileActivity;
import com.cas.jiamin.mogic.R;
import com.cas.jiamin.mogic.Search.SearchActivity;

/** Brief the Share activity that demonstrate the main page of the project
 *  
 */
public class ShareActivity extends AppCompatActivity {
    private static final String TAG = "ShareActivity"; /**< TAG "ShareActivity" for easier reference */

    @Override
	/** Brief onCreate function which is the default runing function to keep the property of the activity
	 *  @param Bundle savedInstanceState
	 */
    protected void onCreate(Bundle savedInstanceState) {
		/** create instance based on current state
		 *  
		 */
        super.onCreate(savedInstanceState);
		/** link current instance to layout activity_home
		 *  
		 */
        setContentView(R.layout.activity_home);
        Log.d(TAG, "onCreate: started.");

		/** create navigation tool bar instance
		 *  
		 */
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomBar);
        /** set navigation tool bar instance clickable
		 *  
		 */
		bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    /** First case link from ShareActivity to HomeActivity
					 *  
					 */
					case R.id.ic_home: {
                        Intent intent1 = new Intent(ShareActivity.this, HomeActivity.class);
                        startActivity(intent1);
                        break;
                    }
					/** Second case link from ShareActivity to SearchActivity
					 *  
					 */
                    case R.id.ic_search: {
                        Intent intent2 = new Intent(ShareActivity.this, SearchActivity.class);
                        startActivity(intent2);
                        break;
                    }
                    /*
                    case R.id.ic_share:{
                        Intent intent3 = new Intent(ShareActivity.this, ShareActivity.class);
                        startActivity(intent3);
                    }
                    */
					/** Third case link from ShareActivity to ProfileActivity
					 *  
					 */
                    case R.id.ic_profile: {
                        Intent intent4 = new Intent(ShareActivity.this, ProfileActivity.class);
                        startActivity(intent4);
                        break;
                    }
                }
                return false;
            }
        });

		/** set labeled icon for local activity
		 *  
		 */
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);
    }
}