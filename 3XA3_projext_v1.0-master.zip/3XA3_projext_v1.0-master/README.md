# Project Name

Team Name: Black-rimmed Glasses

Team Members: Jiamin Zhou, Boyu Jiang, Liam Xu


This project is a reimplementation of photobook "https://github.com/anforaProject/anfora"

The folders and files for this project are as follows:

Doc - Documentation for the project
Code - Implementation
